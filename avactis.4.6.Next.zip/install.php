<?php

function isWritable($dir_name="")
{
    global $msg;
    $dir = $dir_name;
    $fp = @fopen($dir."__test_file__", "w");
    if (!$fp)
    {
        return false;
    }
    fclose($fp);
    @unlink($dir."__test_file__");
    return true;
}

if (isset($_GET["show"]) && $_GET["show"] == "phpinfo")
{
    phpinfo();
    exit();
}

if (isset($_GET["u"]) && isset($_GET["p"]) && isset($_GET['db']))
{
    $server = (isset($_GET['s']) && $_GET['s'] != '')? $_GET['s']:'localhost';
    $user = $_GET["u"];
    $password = $_GET["p"];
    $link = mysql_connect($server, $user, $password);
    if (!$link) {
        die('Could not connect: ' . mysql_error());
    }
    echo 'Connected successfully<br>';

    $database = $_GET['db'];
    $db_selected = mysql_select_db($database, $link);
    if (!$db_selected) {
        die ('Can\'t use foo : ' . mysql_error());
    }
    echo 'DB selected';
    mysql_close($link);
    exit();
}


error_reporting(0);
ini_set("memory_limit", "64M");

if (file_exists("include.php"))
{
    include('include.php');
    exit();
}

if (isset($_GET["logo"]) && $_GET["logo"]=="display")
{
    header("Content-type: image/gif");
    header("Cache-control: public");
    header("Expires: ".date("r",mktime(0,0,0,1,1,2030)));
    header("Cache-control: max-age=".(60*60*24*7));
    header("Last-Modified: ".date("r",filemtime(__FILE__)));

    echo base64_decode($logo);
    exit();
}

if (!file_exists("install.dat"))
{
    die("File install.dat is missing");
}

$md5_hash = "";
$fp_dat = fopen("install.dat", "r");
while(!feof($fp_dat))
{
    $md5_hash.= md5(fread($fp_dat, 1048576));
}
fclose($fp_dat);

if (md5($md5_hash) != "4f39f554f53d91686130c40ec633cae2")
{
    die("File integrity of install.dat could not be verified. Please copy the file again.");
}

if (isWritable())
{
    $dfp = fopen("install.dat", "rb");
    $fp = fopen("include.php", "wb");
    fseek($dfp, 25832384);
    fwrite($fp, gzinflate(base64_decode(fread($dfp, 229536))));
    fclose($dfp);
    fclose($fp);
    $dfp = fopen("install.dat", "rb");
    fseek($dfp, 26061920);
    echo strtr(gzinflate(base64_decode(fread($dfp, 2060))), array("{DIRECTORY}" => dirname(__FILE__)));
    fclose($dfp);
}
else
{
    $dfp = fopen("install.dat", "rb");
    fseek($dfp, 26063980);
    echo strtr(gzinflate(base64_decode(fread($dfp, 2124))), array("{DIRECTORY}" => dirname(__FILE__)));
    fclose($dfp);
}

# 
# cache clean up
#
    $cache_dir = "./avactis-system/cache/";
    
    $dir = @dir($cache_dir);
    if ($dir == null)
    {
       continue;
    }
    while (false !== ($file = $dir->read()))
    {
        if ( strpos($file, '_cache')===0 )
        {
           @unlink($cache_dir.$file);
        }
            
        if (is_dir($cache_dir.$file.'/') && $file != '.' && $file != '..')
        {
           $this->cleanCache($cache_dir.$file.'/');
        }
    }
?>
